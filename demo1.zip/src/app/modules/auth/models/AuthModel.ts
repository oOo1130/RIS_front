export interface AuthModel {
  access_token: string
  refreshToken?: string
}
