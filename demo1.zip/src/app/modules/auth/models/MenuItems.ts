import react from 'react'

export interface MenuItems {
    id: number
    menuItem: string
    menuTo: string
}
