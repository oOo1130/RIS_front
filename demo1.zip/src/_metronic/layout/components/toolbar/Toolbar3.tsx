import React, {FC} from 'react'

const Toolbar3: FC = () => {
  return <>Toolbar 3</>
}

export {Toolbar3}
