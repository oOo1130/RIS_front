import React, {FC} from 'react'

const UserMenu: FC = () => {
  return <></>
}

export {UserMenu}
